try:
    from pyspark import SparkConf
    from pyspark.context import SparkContext
    from pyspark.sql.session import SparkSession
    from pyspark.sql.types import StructType, StructField
    from pyspark.sql.types import DoubleType, IntegerType, StringType
    import pyspark.sql.functions as func
except Exception as e:
    print(e)


def exploration():

    conf = SparkConf().setAppName('eda')
    conf = conf.setMaster('spark://master:7077')
    sc = SparkContext(conf=conf)
    spark = SparkSession(sc)

    #spark = SparkSession.builder.appName('EDA').getOrCreate()

    schema = StructType([
    StructField("neighbourhood", StringType()),
    StructField("latitude", DoubleType()),
    StructField("longitude", DoubleType()),
    StructField("room_type", StringType()),
    StructField("price", IntegerType()),
    StructField("minimum_nights", IntegerType()),
    StructField("availability_365", IntegerType())
    ])
    print("HELLO!")
    df = spark.read.csv("/data/Montreal.csv", header=True, schema=schema)
    df.show(5)

    type(df)
    df.count()
    df.columns

    df_count = df.groupBy("neighbourhood").count()
    df_count.show()

    avg_price = df.groupBy("neighbourhood").agg({"price" : 'mean'})
    # round the price and rename the column
    df_avg_price = avg_price.withColumn("avg(price)", func.round(avg_price["avg(price)"], 2)).withColumnRenamed("avg(price)","average_price")
    df_avg_price.show()

    avg_min_stay = df.groupBy("neighbourhood").agg({"minimum_nights" : 'mean'})
    # round the nights and rename the column
    df_avg_min_stay = avg_min_stay.withColumn("avg(minimum_nights)", func.round(avg_min_stay["avg(minimum_nights)"], 1)).withColumnRenamed("avg(minimum_nights)","avg_min_stay")
    df_avg_min_stay.show()

    # count properties and crosstab
    df_cross = df.crosstab('neighbourhood', 'room_type').withColumnRenamed("Entire home/apt","Home (#)").withColumnRenamed("Private room","Private (#)").withColumnRenamed("Shared room","Shared (#)")
    df_cross = df_cross.withColumnRenamed("neighbourhood_room_type","neighbourhood")
    df_cross.show()

    # avg price per type of room in each district - using table pivoting
    avg_price = df.groupBy("neighbourhood").pivot('room_type').avg("price")
    # round the price and rename the column
    df_avg_price2 = avg_price.withColumn("Entire home/apt", func.round(avg_price["Entire home/apt"], 2)).withColumn("Private room", func.round(avg_price["Private room"], 2)).withColumn("Shared room", func.round(avg_price["Shared room"], 2))
    df_avg_price2 = df_avg_price2.withColumnRenamed("Entire home/apt","Entire ($)").withColumnRenamed("Private room","Private ($)").withColumnRenamed("Shared room","Shared ($)")


    # replace null values by zeros
    df_avg_price2 = df_avg_price2.na.fill(0)
    df_avg_price2.show()

    #merging all 5 created dataframes in one

    df_final = df_count.join(df_avg_price, "neighbourhood")
    df_final = df_final.join(df_avg_min_stay, "neighbourhood")
    df_final = df_final.join(df_avg_price2, "neighbourhood")
    df_final = df_final.join(df_cross, "neighbourhood")
    df_final.show()

    # filter out neighbours having less than 10 offers on AirBnB
    df_final.filter(df_final['count'] > 10).show()
	
    hdfs = "hdfs://hadoop:8020/"
    ## Writing file in CSV format
    df_final.write.format("com.databricks.spark.csv").option("header", "true").mode("overwrite").save(hdfs + "user/me/eda.csv")

    sc.stop()


if __name__ == "__main__":
    exploration()
