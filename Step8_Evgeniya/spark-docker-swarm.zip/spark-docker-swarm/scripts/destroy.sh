#!/bin/bash

docker-machine rm node-1 node-2 node-3 -y
